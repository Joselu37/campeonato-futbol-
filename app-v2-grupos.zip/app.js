/* ==========================================================================
   CAMPEONATO DE FÚTBOL INFANTIL - APP CORE LOGIC (v5.2 Definitiva)
   Club Social y Deportivo Comunicaciones de Mercedes (Corrientes)
   Categorías: 2015, 2016, 2017, 2018, 2019
   ========================================================================== */

// Unregister stale service workers immediately to prevent cached blank responses
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.getRegistrations().then(registrations => {
    for (let registration of registrations) {
      registration.unregister();
    }
  }).catch(() => {});
}

// Escudo Oficial de Club Social y Deportivo Comunicaciones (Mercedes, Corrientes)
const OFFICIAL_COMU_CREST = 'escudo-comunicaciones.webp';

const TEAM_CRESTS = {
  comu: OFFICIAL_COMU_CREST,
  boca: `data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><path d='M50 5 L90 22 L90 60 C90 80 50 95 50 95 C50 95 10 80 10 60 L10 22 Z' fill='%23003b7a' stroke='%23ffcc00' stroke-width='4'/><rect x='10' y='38' width='80' height='24' fill='%23ffcc00'/><text x='50' y='28' text-anchor='middle' font-family='sans-serif' font-weight='900' font-size='14' fill='%23fff'>CABJ</text></svg>`,
  river: `data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><path d='M50 5 L90 22 L90 60 C90 80 50 95 50 95 C50 95 10 80 10 60 L10 22 Z' fill='%23ffffff' stroke='%23d32f2f' stroke-width='4'/><polygon points='15,25 85,75 75,85 10,35' fill='%23d32f2f'/><text x='50' y='55' text-anchor='middle' font-family='sans-serif' font-weight='900' font-size='16' fill='%23111'>CARP</text></svg>`,
  racing: `data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><path d='M50 5 L90 22 L90 60 C90 80 50 95 50 95 C50 95 10 80 10 60 L10 22 Z' fill='%23ffffff' stroke='%2300a8e8' stroke-width='4'/><rect x='22' y='22' width='18' height='60' fill='%2300a8e8'/><rect x='60' y='22' width='18' height='60' fill='%2300a8e8'/><text x='50' y='82' text-anchor='middle' font-family='sans-serif' font-weight='900' font-size='14' fill='%2300a8e8'>RACING</text></svg>`,
  independiente: `data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><path d='M50 5 L90 22 L90 60 C90 80 50 95 50 95 C50 95 10 80 10 60 L10 22 Z' fill='%23d32f2f' stroke='%23ffffff' stroke-width='4'/><circle cx='50' cy='50' r='25' fill='%23ffffff'/><text x='50' y='56' text-anchor='middle' font-family='sans-serif' font-weight='900' font-size='18' fill='%23d32f2f'>CAI</text></svg>`,
  sanlorenzo: `data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><path d='M50 5 L90 22 L90 60 C90 80 50 95 50 95 C50 95 10 80 10 60 L10 22 Z' fill='%23002b49' stroke='%23d32f2f' stroke-width='4'/><rect x='15' y='22' width='70' height='10' fill='%23d32f2f'/><rect x='15' y='42' width='70' height='10' fill='%23d32f2f'/><rect x='15' y='62' width='70' height='10' fill='%23d32f2f'/><text x='50' y='55' text-anchor='middle' font-family='sans-serif' font-weight='900' font-size='14' fill='%23fff'>CASLA</text></svg>`,
  velez: `data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><path d='M50 5 L90 22 L90 60 C90 80 50 95 50 95 C50 95 10 80 10 60 L10 22 Z' fill='%23ffffff' stroke='%230038a8' stroke-width='4'/><polygon points='20,25 50,60 80,25' fill='%230038a8'/><text x='50' y='82' text-anchor='middle' font-family='sans-serif' font-weight='900' font-size='14' fill='%230038a8'>CAVS</text></svg>`,
  rosariocentral: `data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><path d='M50 5 L90 22 L90 60 C90 80 50 95 50 95 C50 95 10 80 10 60 L10 22 Z' fill='%23002b49' stroke='%23ffcc00' stroke-width='4'/><rect x='20' y='22' width='15' height='60' fill='%23ffcc00'/><rect x='65' y='22' width='15' height='60' fill='%23ffcc00'/><text x='50' y='55' text-anchor='middle' font-family='sans-serif' font-weight='900' font-size='14' fill='%23ffcc00'>CARC</text></svg>`,
  talleres: `data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><path d='M50 5 L90 22 L90 60 C90 80 50 95 50 95 C50 95 10 80 10 60 L10 22 Z' fill='%23ffffff' stroke='%23001f54' stroke-width='4'/><rect x='25' y='22' width='12' height='60' fill='%23001f54'/><rect x='44' y='22' width='12' height='60' fill='%23001f54'/><rect x='63' y='22' width='12' height='60' fill='%23001f54'/><text x='50' y='82' text-anchor='middle' font-family='sans-serif' font-weight='900' font-size='14' fill='%23001f54'>CAT</text></svg>`,
  lanus: `data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><path d='M50 5 L90 22 L90 60 C90 80 50 95 50 95 C50 95 10 80 10 60 L10 22 Z' fill='%23800020' stroke='%23ffffff' stroke-width='4'/><circle cx='50' cy='50' r='25' fill='%23ffffff'/><text x='50' y='56' text-anchor='middle' font-family='sans-serif' font-weight='900' font-size='16' fill='%23800020'>CAL</text></svg>`,
  newells: `data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><path d='M50 5 L90 22 L90 60 C90 80 50 95 50 95 C50 95 10 80 10 60 L10 22 Z' fill='%23000000' stroke='%23ffffff' stroke-width='4'/><path d='M50 5 L90 22 L90 60 C90 80 50 95 50 95 Z' fill='%23d32f2f'/><text x='50' y='56' text-anchor='middle' font-family='sans-serif' font-weight='900' font-size='15' fill='%23ffffff'>NOB</text></svg>`,
  huracan: `data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><path d='M50 5 L90 22 L90 60 C90 80 50 95 50 95 C50 95 10 80 10 60 L10 22 Z' fill='%23ffffff' stroke='%23dc2626' stroke-width='4'/><circle cx='50' cy='45' r='18' fill='%23dc2626'/><text x='50' y='82' text-anchor='middle' font-family='sans-serif' font-weight='900' font-size='14' fill='%23dc2626'>CAH</text></svg>`
};

const DEFAULT_12_TEAMS = [
  { id: 'comu', name: 'Comunicaciones (Mercedes)', short: 'COM', crest: OFFICIAL_COMU_CREST, isHost: true },
  { id: 'boca', name: 'Boca Juniors', short: 'BOC', crest: TEAM_CRESTS.boca },
  { id: 'river', name: 'River Plate', short: 'RIV', crest: TEAM_CRESTS.river },
  { id: 'racing', name: 'Racing Club', short: 'RAC', crest: TEAM_CRESTS.racing },
  { id: 'independiente', name: 'Independiente', short: 'IND', crest: TEAM_CRESTS.independiente },
  { id: 'sanlorenzo', name: 'San Lorenzo', short: 'SLO', crest: TEAM_CRESTS.sanlorenzo },
  { id: 'velez', name: 'Vélez Sarsfield', short: 'VEL', crest: TEAM_CRESTS.velez },
  { id: 'rosariocentral', name: 'Rosario Central', short: 'CEN', crest: TEAM_CRESTS.rosariocentral },
  { id: 'talleres', name: 'Talleres de Córdoba', short: 'TAL', crest: TEAM_CRESTS.talleres },
  { id: 'lanus', name: 'Club Atlético Lanús', short: 'LAN', crest: TEAM_CRESTS.lanus },
  { id: 'newells', name: "Newell's Old Boys", short: 'NOB', crest: TEAM_CRESTS.newells },
  { id: 'huracan', name: 'Club Atlético Huracán', short: 'HUR', crest: TEAM_CRESTS.huracan }
];

const DEFAULT_SPONSORS = [
  { 
    id: 's1', 
    name: 'Gobierno de Corrientes', 
    tier: 'main', 
    logo: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 70"><rect width="240" height="70" rx="10" fill="%23111827" stroke="%23ffd700" stroke-width="3"/><circle cx="38" cy="35" r="20" fill="%23ffd700"/><path d="M38 20 L42 30 L52 32 L44 39 L47 49 L38 43 L29 49 L32 39 L24 32 L34 30 Z" fill="%23111827"/><text x="135" y="32" text-anchor="middle" font-family="Arial, sans-serif" font-weight="900" font-size="12" fill="%23ffd700" letter-spacing="1">GOBIERNO DE</text><text x="135" y="52" text-anchor="middle" font-family="Arial, sans-serif" font-weight="900" font-size="16" fill="%23ffffff" letter-spacing="1.5">CORRIENTES</text></svg>`, 
    url: 'https://www.corrientes.gob.ar/' 
  },
  { 
    id: 's2', 
    name: 'Municipalidad de Mercedes', 
    tier: 'main', 
    logo: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 70"><rect width="240" height="70" rx="10" fill="%23ffd700" stroke="%23000000" stroke-width="3"/><rect x="10" y="10" width="220" height="50" rx="6" fill="%23000000"/><text x="120" y="32" text-anchor="middle" font-family="Arial, sans-serif" font-weight="900" font-size="11" fill="%23ffd700" letter-spacing="1">MUNICIPALIDAD DE</text><text x="120" y="53" text-anchor="middle" font-family="Arial, sans-serif" font-weight="900" font-size="17" fill="%23ffffff" letter-spacing="2">MERCEDES</text></svg>`, 
    url: 'https://mercedes.gob.ar/' 
  },
  { 
    id: 's3', 
    name: 'Supermercado El Cartero', 
    tier: 'gold', 
    logo: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 70"><rect width="240" height="70" rx="10" fill="%2316a34a" stroke="%23ffd700" stroke-width="2.5"/><text x="120" y="30" text-anchor="middle" font-family="Arial, sans-serif" font-weight="900" font-size="11" fill="%23ffd700" letter-spacing="1">SUPERMERCADOS</text><text x="120" y="53" text-anchor="middle" font-family="Arial, sans-serif" font-weight="900" font-size="17" fill="%23ffffff" letter-spacing="1">EL CARTERO</text></svg>`, 
    url: '#' 
  },
  { 
    id: 's4', 
    name: 'Yerba Mate Taragüí', 
    tier: 'gold', 
    logo: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 70"><rect width="240" height="70" rx="10" fill="%23dc2626" stroke="%23ffffff" stroke-width="2.5"/><text x="120" y="45" text-anchor="middle" font-family="Arial, sans-serif" font-weight="900" font-size="21" fill="%23ffd700" letter-spacing="2">TARAGÜÍ</text></svg>`, 
    url: 'https://www.taragui.com/' 
  },
  { 
    id: 's5', 
    name: 'Banco de Corrientes', 
    tier: 'silver', 
    logo: `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 70"><rect width="240" height="70" rx="10" fill="%231e3a8a" stroke="%2360a5fa" stroke-width="2.5"/><text x="120" y="31" text-anchor="middle" font-family="Arial, sans-serif" font-weight="900" font-size="11" fill="%2393c5fd" letter-spacing="1">BANCO DE</text><text x="120" y="52" text-anchor="middle" font-family="Arial, sans-serif" font-weight="900" font-size="16" fill="%23ffffff" letter-spacing="1.5">CORRIENTES</text></svg>`, 
    url: 'https://www.bancodecorrientes.com.ar/' 
  }
];

const CATEGORIES = ['2015', '2016', '2017', '2018', '2019'];

// Global App State
let appState = {
  currentCategory: '2015',
  currentTab: 'fixture',
  categoriesData: {},
  sponsors: DEFAULT_SPONSORS,
  isAdmin: false
};

// --------------------------------------------------------------------------
// SINCRONIZACIÓN EN TIEMPO REAL (Firebase Realtime Database + Authentication)
// --------------------------------------------------------------------------
// Todo lo que es "dato compartido del torneo" (equipos, fixtures, resultados,
// cruces, sponsors) vive en un único nodo de Firebase: "comu_torneo_state".
// Cada dispositivo escucha ese nodo en vivo: en cuanto alguien (el admin)
// hace un cambio, se escribe en Firebase y todos los demás dispositivos que
// tengan la app abierta lo reciben y re-renderizan al instante, sin recargar.
//
// La escritura está protegida por una regla de seguridad de Firebase que
// exige haber iniciado sesión con la cuenta de administrador (Firebase
// Authentication), así que el login de admin usa email + contraseña reales
// en vez de un PIN local.
//
// "currentCategory" y "currentTab" quedan fuera de la sync: son preferencias
// de navegación propias de cada dispositivo, no datos del torneo.

let fbSyncRef = null;
let fbSyncReady = false;
let fbHasReceivedFirstSnapshot = false;
let fbApplyingRemoteUpdate = false;
let fbSyncTimeout = null;
let fbAuth = null;

const SYNC_FIELDS = ['categoriesData', 'sponsors'];

function initFirebaseSync() {
  try {
    if (typeof firebase === 'undefined' || !window.COMU_FIREBASE_CONFIG) {
      console.warn('Firebase no está disponible: la app funcionará solo en modo local (sin sincronización entre dispositivos).');
      setSyncStatus('offline');
      return;
    }

    setSyncStatus('connecting');

    if (!firebase.apps || !firebase.apps.length) {
      firebase.initializeApp(window.COMU_FIREBASE_CONFIG);
    }

    const db = firebase.database();
    fbAuth = firebase.auth();
    fbSyncRef = db.ref('comu_torneo_state');

    // Mantiene appState.isAdmin sincronizado con la sesión real de Firebase,
    // y persiste automáticamente entre recargas (el SDK guarda la sesión).
    fbAuth.onAuthStateChanged((user) => {
      appState.isAdmin = !!user;
      renderAdminHeaderStatus();
      safeRenderApp();
    });

    // Marca visualmente si se corta la conexión a internet / a Firebase.
    db.ref('.info/connected').on('value', (snap) => {
      if (snap.val() === true) {
        if (fbHasReceivedFirstSnapshot) setSyncStatus('live');
      } else {
        setSyncStatus('connecting');
      }
    });

    fbSyncRef.on('value', (snapshot) => {
      const remote = snapshot.val();

      if (remote && remote.categoriesData) {
        fbApplyingRemoteUpdate = true;
        try {
          SYNC_FIELDS.forEach(field => {
            if (remote[field] !== undefined) appState[field] = remote[field];
          });
          saveLocalStateOnly();
          safeRenderApp();
        } finally {
          fbApplyingRemoteUpdate = false;
        }
      }

      if (!fbHasReceivedFirstSnapshot) {
        fbHasReceivedFirstSnapshot = true;
        fbSyncReady = true;
        setSyncStatus('live');
        if ((!remote || !remote.categoriesData) && appState.isAdmin) {
          // Todavía no hay nada en Firebase: si quien abrió la app ya es
          // admin, "siembra" el estado inicial para que el resto se
          // sincronice a partir de acá. Si no es admin, espera a que un
          // admin inicie sesión (la regla de seguridad no permite escribir
          // sin autenticarse).
          pushStateToFirebase();
        }
      }
    }, (err) => {
      console.error('Error de sincronización con Firebase:', err);
      setSyncStatus('offline');
    });
  } catch (e) {
    console.error('No se pudo inicializar Firebase:', e);
    setSyncStatus('offline');
  }
}

function pushStateToFirebase() {
  if (!fbSyncRef) return;
  try {
    fbSyncRef.set({
      categoriesData: appState.categoriesData,
      sponsors: appState.sponsors,
      updatedAt: (typeof firebase !== 'undefined' && firebase.database && firebase.database.ServerValue)
        ? firebase.database.ServerValue.TIMESTAMP
        : Date.now()
    }).catch((e) => {
      console.error('Error guardando en Firebase:', e);
      if (e && e.code === 'PERMISSION_DENIED') {
        alert('No se pudo guardar: tu sesión de administrador no es válida o expiró. Cerrá sesión y volvé a ingresar.');
      } else {
        alert('No se pudo guardar el cambio (' + (e && e.message ? e.message : 'error desconocido') + '). Probá de nuevo.');
      }
    });
  } catch (e) {
    console.error('Error enviando datos a Firebase:', e);
  }
}

// Debounce chico para no mandar decenas de escrituras seguidas cuando el
// admin hace varios cambios rápidos (por ejemplo, cargar varios resultados).
function scheduleFirebasePush() {
  if (!fbSyncReady || fbApplyingRemoteUpdate || !appState.isAdmin) return;
  if (fbSyncTimeout) clearTimeout(fbSyncTimeout);
  fbSyncTimeout = setTimeout(() => {
    fbSyncTimeout = null;
    pushStateToFirebase();
  }, 150);
}

function setSyncStatus(status) {
  const badge = document.getElementById('syncStatusBadge');
  if (!badge) return;
  const modes = {
    live: { cls: 'is-live', dot: '', text: '🟢 En vivo' },
    connecting: { cls: 'is-connecting', dot: '', text: '🟡 Conectando…' },
    offline: { cls: 'is-offline', dot: '', text: '⚪ Sin conexión' }
  };
  const m = modes[status] || modes.offline;
  badge.className = 'sync-status-badge ' + m.cls;
  badge.innerHTML = `<span class="sync-dot"></span><span class="sync-label">${m.text}</span>`;
}

// Initialize App Data & Migration Safety
function initData() {
  try {
    const savedData = localStorage.getItem('comu_torneo_app_state_v5');
    if (savedData) {
      const parsed = JSON.parse(savedData);
      if (parsed && parsed.categoriesData) {
        appState.currentCategory = parsed.currentCategory || '2015';
        appState.currentTab = parsed.currentTab || 'fixture';
        appState.categoriesData = parsed.categoriesData;

        // Repair any category data structure if needed
        CATEGORIES.forEach(cat => {
          let catData = appState.categoriesData[cat];
          if (!catData) {
            catData = {
              format: 'groups_cup',
              teams: JSON.parse(JSON.stringify(DEFAULT_12_TEAMS)),
              groups: { A: [], B: [], C: [] },
              fixtures: [],
              playoffs: createEmptyPlayoffsObj()
            };
            appState.categoriesData[cat] = catData;
            executeGroupDrawBackend(cat, false);
          } else {
            if (!catData.format) catData.format = 'groups_cup';
            if (!catData.teams || !Array.isArray(catData.teams) || catData.teams.length === 0) {
              catData.teams = JSON.parse(JSON.stringify(DEFAULT_12_TEAMS));
            }
            if (!catData.groups || !catData.groups.A || catData.groups.A.length === 0) {
              catData.groups = { A: [], B: [], C: [] };
              executeGroupDrawBackend(cat, false);
            }
            if (!catData.fixtures || !Array.isArray(catData.fixtures) || catData.fixtures.length === 0) {
              catData.fixtures = generateGroupsFixtures(catData.groups, cat);
            }
            if (!catData.playoffs || !catData.playoffs.initialCruces) {
              const repairNumGroups = catData.numGroups || Object.keys(catData.groups || {}).length || 3;
              catData.playoffs = createEmptyPlayoffsObj(repairNumGroups);
            }
          }
        });

        appState.sponsors = (parsed.sponsors && parsed.sponsors.length) ? parsed.sponsors : DEFAULT_SPONSORS;
        return;
      }
    }
  } catch (e) {
    console.error('Error loading stored state, performing clean reset:', e);
  }

  // Fallback: Clear corrupted state and generate clean state
  try {
    localStorage.removeItem('comu_torneo_app_state_v4');
    localStorage.removeItem('comu_torneo_app_state_v5');
  } catch (e) {}

  generateDefaultTournamentState();
}

function saveState() {
  saveLocalStateOnly();
  // Si el cambio vino de un dato que acabamos de recibir de Firebase, no lo
  // reenviamos (evita un eco infinito). Si es un cambio genuino del usuario
  // (admin cargando un resultado, etc.), lo propagamos a todos los demás
  // dispositivos conectados.
  if (!fbApplyingRemoteUpdate) {
    scheduleFirebasePush();
  }
}

// Guarda el estado únicamente en el localStorage de este dispositivo,
// sin tocar Firebase. Se usa tanto desde saveState() como al recibir
// actualizaciones remotas (para no perder los datos si el usuario cierra
// la app sin haber tocado nada).
function saveLocalStateOnly() {
  try {
    const dataToSave = {
      currentCategory: appState.currentCategory,
      currentTab: appState.currentTab,
      categoriesData: appState.categoriesData,
      sponsors: appState.sponsors
    };
    localStorage.setItem('comu_torneo_app_state_v5', JSON.stringify(dataToSave));
  } catch (e) {
    console.error('Error saving state to localStorage:', e);
    if (e && e.name === 'QuotaExceededError') {
      alert('No se pudo guardar: se llenó el espacio de almacenamiento (demasiadas fotos/escudos pesados). Los últimos cambios NO se guardaron. Borrá algún escudo o logo de sponsor pesado desde el panel de admin, o subí imágenes más livianas.');
    }
  }
}

// Comprime y redimensiona una imagen antes de convertirla a base64,
// para evitar llenar el localStorage con fotos pesadas sin procesar.
function resizeImageToDataURL(file, maxDim = 220, quality = 0.72) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;
        if (width > height) {
          if (width > maxDim) { height = Math.round(height * (maxDim / width)); width = maxDim; }
        } else {
          if (height > maxDim) { width = Math.round(width * (maxDim / height)); height = maxDim; }
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.onerror = () => reject(new Error('No se pudo procesar la imagen.'));
      img.src = e.target.result;
    };
    reader.onerror = () => reject(new Error('No se pudo leer el archivo.'));
    reader.readAsDataURL(file);
  });
}

function generateDefaultTournamentState() {
  appState.categoriesData = {};
  CATEGORIES.forEach(cat => {
    const teams = JSON.parse(JSON.stringify(DEFAULT_12_TEAMS));
    appState.categoriesData[cat] = {
      format: 'groups_cup',
      teams: teams,
      groups: { A: [], B: [], C: [] },
      fixtures: [],
      playoffs: createEmptyPlayoffsObj()
    };
    executeGroupDrawBackend(cat, false);
  });
  appState.sponsors = [...DEFAULT_SPONSORS];
  saveLocalStateOnly();
}

function generateGroupLetters(n) {
  const letters = [];
  for (let i = 0; i < n; i++) letters.push(String.fromCharCode(65 + i));
  return letters;
}

function createEmptyPlayoffsObj(numGroups = 3) {
  const initialCruces = numGroups === 2 ? [
      { id: 'cruce_0', label: '1° Grupo A vs 4° Grupo B', home: null, away: null, homeScore: null, awayScore: null, winner: null, loser: null, dayDate: 'Sábado - 15:00 hs' },
      { id: 'cruce_1', label: '1° Grupo B vs 4° Grupo A', home: null, away: null, homeScore: null, awayScore: null, winner: null, loser: null, dayDate: 'Sábado - 16:15 hs' },
      { id: 'cruce_2', label: '2° Grupo A vs 3° Grupo B', home: null, away: null, homeScore: null, awayScore: null, winner: null, loser: null, dayDate: 'Sábado - 17:30 hs' },
      { id: 'cruce_3', label: '2° Grupo B vs 3° Grupo A', home: null, away: null, homeScore: null, awayScore: null, winner: null, loser: null, dayDate: 'Sábado - 18:45 hs' }
    ] : [
      { id: 'cruce_0', label: '1er Mejor 1° vs 2do Mejor 3°', home: null, away: null, homeScore: null, awayScore: null, winner: null, loser: null, dayDate: 'Sábado - 15:00 hs' },
      { id: 'cruce_1', label: '2do Mejor 1° vs 1er Mejor 3°', home: null, away: null, homeScore: null, awayScore: null, winner: null, loser: null, dayDate: 'Sábado - 16:15 hs' },
      { id: 'cruce_2', label: '3er Mejor 1° vs Peor 2°', home: null, away: null, homeScore: null, awayScore: null, winner: null, loser: null, dayDate: 'Sábado - 17:30 hs' },
      { id: 'cruce_3', label: '1er Mejor 2° vs 2do Mejor 2°', home: null, away: null, homeScore: null, awayScore: null, winner: null, loser: null, dayDate: 'Sábado - 18:45 hs' }
    ];

  return {
    initialCruces: initialCruces,
    oroSemis: [
      { id: 'oro_semi_0', home: null, away: null, homeScore: null, awayScore: null, winner: null, loser: null, dayDate: 'Domingo - 10:00 hs' },
      { id: 'oro_semi_1', home: null, away: null, homeScore: null, awayScore: null, winner: null, loser: null, dayDate: 'Domingo - 11:15 hs' }
    ],
    oroFinal: { id: 'oro_final', home: null, away: null, homeScore: null, awayScore: null, winner: null, dayDate: 'Gran Final Copa de Oro' },
    oroThird: { id: 'oro_third', home: null, away: null, homeScore: null, awayScore: null, winner: null, dayDate: '3er Puesto Copa de Oro' },
    plataSemis: [
      { id: 'plata_semi_0', home: null, away: null, homeScore: null, awayScore: null, winner: null, loser: null, dayDate: 'Domingo - 09:00 hs' },
      { id: 'plata_semi_1', home: null, away: null, homeScore: null, awayScore: null, winner: null, loser: null, dayDate: 'Domingo - 10:15 hs' }
    ],
    plataFinal: { id: 'plata_final', home: null, away: null, homeScore: null, awayScore: null, winner: null, dayDate: 'Gran Final Copa de Plata' },
    plataThird: { id: 'plata_third', home: null, away: null, homeScore: null, awayScore: null, winner: null, dayDate: '3er Puesto Copa de Plata' },
    oroDrawn: false,
    plataDrawn: false,
    generated: false,
    numGroups: numGroups
  };
}

// --------------------------------------------------------------------------
// FORMAT SWITCHING & GROUP DRAW BACKEND LOGIC
// --------------------------------------------------------------------------

// Devuelve true si la categoría ya tiene partidos EN VIVO o FINALIZADOS cargados
// (resultados reales), para evitar regenerar el fixture y perderlos sin avisar.
function categoryHasRealProgress(catData) {
  if (!catData) return false;
  return (catData.fixtures || []).some(j => (j.matches || []).some(m => m.status === 'finished' || m.status === 'live'));
}

function confirmOverwriteIfNeeded(catYear, catData) {
  if (!categoryHasRealProgress(catData)) return true;
  return confirm(`⚠️ La categoría ${catYear} ya tiene partidos EN VIVO o FINALIZADOS cargados.\n\nEsta acción va a REGENERAR el fixture completo y esos resultados reales se PERDERÍAN.\n\n¿Confirmás que querés continuar de todas formas?`);
}

function switchCategoryFormat(catYear, newFormat) {
  if (!appState.isAdmin) return openAdminPinModal();
  const catData = appState.categoriesData[catYear];
  if (!catData) return;

  if (catData.format === newFormat) return;
  if (!confirmOverwriteIfNeeded(catYear, catData)) return;

  catData.format = newFormat;
  if (newFormat === 'groups_cup') {
    if (catData.groupsSource === 'manual' && catData.groups && Object.keys(catData.groups).length > 0) {
      // Los grupos ya fueron cargados a mano (sorteo real, informado a los equipos):
      // solo se regenera el fixture con esos grupos, sin volver a sortear al azar.
      const numGroups = catData.numGroups || Object.keys(catData.groups).length;
      catData.fixtures = generateGroupsFixtures(catData.groups, catYear);
      catData.playoffs = createEmptyPlayoffsObj(numGroups);
    } else {
      executeGroupDrawBackend(catYear, false);
    }
  } else {
    catData.fixtures = generateSingleTableFixture(catData.teams, catYear);
    catData.playoffs = createEmptyPlayoffsObj();
  }
  saveState();
  safeRenderApp();
}

function executeGroupDrawBackend(catYear, resetScores = true) {
  const catData = appState.categoriesData[catYear];
  if (!catData || !catData.teams || catData.teams.length === 0) return;

  const numGroups = catData.numGroups || 3;
  const groupLetters = generateGroupLetters(numGroups);

  const shuffled = [...catData.teams].sort(() => Math.random() - 0.5);
  const groups = {};
  groupLetters.forEach(l => { groups[l] = []; });

  shuffled.forEach((team, index) => {
    const letter = groupLetters[index % numGroups];
    groups[letter].push(team.id);
  });

  catData.groups = groups;
  catData.numGroups = numGroups;
  catData.groupsSource = 'random';
  catData.fixtures = generateGroupsFixtures(groups, catYear);
  catData.playoffs = createEmptyPlayoffsObj(numGroups);

  if (resetScores) {
    saveState();
  }
}

function generateGroupsFixtures(groups, catYear) {
  const allJornadas = [];
  const groupKeys = Object.keys(groups || {}).sort();

  groupKeys.forEach(grpKey => {
    const teamIds = (groups && groups[grpKey]) ? groups[grpKey] : [];
    if (teamIds.length < 2) return;

    for (let r = 0; r < teamIds.length - 1; r++) {
      let jornadaObj = allJornadas[r];
      if (!jornadaObj) {
        jornadaObj = { jornadaNumber: r + 1, matches: [] };
        allJornadas[r] = jornadaObj;
      }

      for (let i = 0; i < Math.floor(teamIds.length / 2); i++) {
        const homeIdx = (r + i) % (teamIds.length - 1);
        let awayIdx = (teamIds.length - 1 - i + r) % (teamIds.length - 1);
        if (i === 0) awayIdx = teamIds.length - 1;

        const homeId = teamIds[homeIdx];
        const awayId = teamIds[awayIdx];

        if (homeId && awayId) {
          const matchId = `m_${catYear}_grp${grpKey}_j${r + 1}_${i}`;
          jornadaObj.matches.push({
            id: matchId,
            group: grpKey,
            home: homeId,
            away: awayId,
            homeScore: null,
            awayScore: null,
            status: 'scheduled',
            dayDate: `Jornada ${r + 1}`,
            time: `${9 + (r * 2) + i}:00 hs`,
            pitch: `Cancha Grupo ${grpKey}`
          });
        }
      }
    }
  });

  return allJornadas.filter(j => j && j.matches && j.matches.length > 0);
}

function generateSingleTableFixture(teams, catYear) {
  const rounds = [];
  const teamList = teams || [];
  for (let i = 0; i < Math.min(3, teamList.length - 1); i++) {
    const matches = [];
    for (let j = 0; j < Math.floor(teamList.length / 2); j++) {
      const home = teamList[j];
      const away = teamList[teamList.length - 1 - j];
      if (home && away) {
        matches.push({
          id: `m_${catYear}_gen_j${i + 1}_${j}`,
          group: null,
          home: home.id,
          away: away.id,
          homeScore: null,
          awayScore: null,
          status: 'scheduled',
          dayDate: `Fecha ${i + 1}`,
          time: '10:00 hs',
          pitch: 'Cancha Estadio'
        });
      }
    }
    rounds.push({ jornadaNumber: i + 1, matches: matches });
  }
  return rounds;
}

// --------------------------------------------------------------------------
// STANDINGS & QUALIFIED RANKING CALCULATIONS
// --------------------------------------------------------------------------

function calculateGroupStandings(category, groupLetter) {
  const catData = appState.categoriesData ? appState.categoriesData[category] : null;
  if (!catData) return [];

  const groupTeamIds = (catData.groups && catData.groups[groupLetter]) ? catData.groups[groupLetter] : [];
  const stats = {};

  groupTeamIds.forEach(teamId => {
    const teamObj = getTeamObj(teamId);
    stats[teamId] = {
      ...teamObj,
      group: groupLetter,
      pts: 0, pj: 0, pg: 0, pe: 0, pp: 0, gf: 0, gc: 0, dg: 0
    };
  });

  (catData.fixtures || []).forEach(round => {
    (round.matches || []).forEach(m => {
      if (m.group === groupLetter && m.status === 'finished' && m.homeScore !== null && m.awayScore !== null) {
        const home = stats[m.home];
        const away = stats[m.away];
        if (home && away) {
          home.pj += 1; away.pj += 1;
          home.gf += m.homeScore; home.gc += m.awayScore;
          away.gf += m.awayScore; away.gc += m.homeScore;

          if (m.homeScore > m.awayScore) {
            home.pts += 3; home.pg += 1; away.pp += 1;
          } else if (m.homeScore < m.awayScore) {
            away.pts += 3; away.pg += 1; home.pp += 1;
          } else {
            home.pts += 1; away.pts += 1; home.pe += 1; away.pe += 1;
          }
        }
      }
    });
  });

  return Object.values(stats).map(t => {
    t.dg = t.gf - t.gc;
    return t;
  }).sort(sortTeamsComparator);
}

function sortTeamsComparator(a, b) {
  if (!a || !b) return 0;
  if (b.pts !== a.pts) return (b.pts || 0) - (a.pts || 0);
  if (b.dg !== a.dg) return (b.dg || 0) - (a.dg || 0);
  if (b.gf !== a.gf) return (b.gf || 0) - (a.gf || 0);
  return (a.name || '').localeCompare(b.name || '');
}

function calculateQualifiedTeamsRanking(category) {
  const catData = appState.categoriesData ? appState.categoriesData[category] : null;
  const numGroups = (catData && catData.numGroups) || Object.keys((catData && catData.groups) || {}).length || 3;

  if (numGroups === 2) {
    return calculateCrossQualification(category);
  }

  const tableA = calculateGroupStandings(category, 'A') || [];
  const tableB = calculateGroupStandings(category, 'B') || [];
  const tableC = calculateGroupStandings(category, 'C') || [];

  const primeros = [tableA[0], tableB[0], tableC[0]].filter(Boolean).sort(sortTeamsComparator);
  const segundos = [tableA[1], tableB[1], tableC[1]].filter(Boolean).sort(sortTeamsComparator);
  const terceros = [tableA[2], tableB[2], tableC[2]].filter(Boolean).sort(sortTeamsComparator);

  const mejoresTerceros = terceros.slice(0, 2);

  const qualifiedList = [
    { rankLabel: '1er Mejor 1°', team: primeros[0] || null },
    { rankLabel: '2do Mejor 1°', team: primeros[1] || null },
    { rankLabel: '3er Mejor 1°', team: primeros[2] || null },
    { rankLabel: '1er Mejor 2°', team: segundos[0] || null },
    { rankLabel: '2do Mejor 2°', team: segundos[1] || null },
    { rankLabel: '3er Segundo (Peor 2°)', team: segundos[2] || null },
    { rankLabel: '1er Mejor 3°', team: mejoresTerceros[0] || null },
    { rankLabel: '2do Mejor 3°', team: mejoresTerceros[1] || null }
  ];

  return { primeros, segundos, terceros, mejoresTerceros, qualifiedList };
}

// Clasificación para categorías con 2 grupos de 4: pasan los 8 equipos,
// cruzando grupos: 1° de cada grupo vs 4° del otro grupo, y 2° vs 3° del otro grupo.
function calculateCrossQualification(category) {
  const tableA = calculateGroupStandings(category, 'A') || [];
  const tableB = calculateGroupStandings(category, 'B') || [];

  const cruces = [
    { home: tableA[0] ? tableA[0].id : null, away: tableB[3] ? tableB[3].id : null },
    { home: tableB[0] ? tableB[0].id : null, away: tableA[3] ? tableA[3].id : null },
    { home: tableA[1] ? tableA[1].id : null, away: tableB[2] ? tableB[2].id : null },
    { home: tableB[1] ? tableB[1].id : null, away: tableA[2] ? tableA[2].id : null }
  ];

  const qualifiedList = [
    { rankLabel: '1° Grupo A', team: tableA[0] || null, matchLabel: 'vs 4° Grupo B (Cruce 1)' },
    { rankLabel: '4° Grupo B', team: tableB[3] || null, matchLabel: 'vs 1° Grupo A (Cruce 1)' },
    { rankLabel: '1° Grupo B', team: tableB[0] || null, matchLabel: 'vs 4° Grupo A (Cruce 2)' },
    { rankLabel: '4° Grupo A', team: tableA[3] || null, matchLabel: 'vs 1° Grupo B (Cruce 2)' },
    { rankLabel: '2° Grupo A', team: tableA[1] || null, matchLabel: 'vs 3° Grupo B (Cruce 3)' },
    { rankLabel: '3° Grupo B', team: tableB[2] || null, matchLabel: 'vs 2° Grupo A (Cruce 3)' },
    { rankLabel: '2° Grupo B', team: tableB[1] || null, matchLabel: 'vs 3° Grupo A (Cruce 4)' },
    { rankLabel: '3° Grupo A', team: tableA[2] || null, matchLabel: 'vs 2° Grupo B (Cruce 4)' }
  ];

  return { tableA, tableB, cruces, qualifiedList };
}

function calculateSingleStandings(category) {
  const catData = appState.categoriesData ? appState.categoriesData[category] : null;
  if (!catData) return [];

  const stats = {};
  (catData.teams || []).forEach(t => {
    stats[t.id] = { ...t, pts: 0, pj: 0, pg: 0, pe: 0, pp: 0, gf: 0, gc: 0, dg: 0 };
  });

  (catData.fixtures || []).forEach(round => {
    (round.matches || []).forEach(m => {
      if (m.status === 'finished' && m.homeScore !== null && m.awayScore !== null) {
        const home = stats[m.home];
        const away = stats[m.away];
        if (home && away) {
          home.pj += 1; away.pj += 1;
          home.gf += m.homeScore; home.gc += m.awayScore;
          away.gf += m.awayScore; away.gc += m.homeScore;

          if (m.homeScore > m.awayScore) {
            home.pts += 3; home.pg += 1; away.pp += 1;
          } else if (m.homeScore < m.awayScore) {
            away.pts += 3; away.pg += 1; home.pp += 1;
          } else {
            home.pts += 1; away.pts += 1; home.pe += 1; away.pe += 1;
          }
        }
      }
    });
  });

  return Object.values(stats).map(t => {
    t.dg = t.gf - t.gc;
    return t;
  }).sort(sortTeamsComparator);
}

// --------------------------------------------------------------------------
// RENDER VIEWS WITH SAFE ERROR HANDLING
// --------------------------------------------------------------------------

function safeRenderApp() {
  try {
    renderApp();
  } catch (err) {
    console.error('Render error encountered, auto-healing state:', err);
    generateDefaultTournamentState();
    renderApp();
  }
}

function renderApp() {
  renderAdminHeaderStatus();
  renderMarqueeSponsors();
  renderCategoryPills();
  renderTabButtons();
  renderMainContent();
  renderFooterSponsors();
}

function renderAdminHeaderStatus() {
  const container = document.getElementById('adminHeaderBtn');
  if (!container) return;
  if (appState.isAdmin) {
    container.innerHTML = `
      <button class="btn-primary" style="background: #22c55e; color: #fff;" onclick="logoutAdmin()">
        🔓 Admin (Cerrar Sesión)
      </button>
    `;
  } else {
    container.innerHTML = `
      <button class="btn-secondary" onclick="openAdminPinModal()">
        🔐 Ingresar Admin
      </button>
    `;
  }
}

function renderCategoryPills() {
  const container = document.getElementById('categoryPills');
  if (!container) return;
  container.innerHTML = CATEGORIES.map(cat => `
    <button class="cat-btn ${appState.currentCategory === cat ? 'active' : ''}" onclick="selectCategory('${cat}')">
      Cat. ${cat}
    </button>
  `).join('');
}

function renderTabButtons() {
  const catData = appState.categoriesData ? appState.categoriesData[appState.currentCategory] : null;
  const isGroups = catData && catData.format === 'groups_cup';

  const tabs = [
    { id: 'fixture', label: '📅 Fixture y Horarios' },
    { id: 'standings', label: isGroups ? '🏆 Posiciones y Grupos' : '🏆 Tabla de Posiciones' },
    { id: 'cruces', label: isGroups ? '⚔️ Cruces, Copa Oro y Plata' : '⚔️ Cruces y Gran Final' },
    { id: 'teams', label: '👥 Equipos de la Categoría' },
    { id: 'sponsors', label: '🤝 Auspiciantes / Sponsors' },
    { id: 'app', label: '📱 Descargar App' }
  ];

  const container = document.getElementById('viewTabs');
  if (!container) return;
  container.innerHTML = tabs.map(tab => `
    <button class="tab-btn ${appState.currentTab === tab.id ? 'active' : ''}" onclick="selectTab('${tab.id}')">
      ${tab.label}
    </button>
  `).join('');
}

function renderMarqueeSponsors() {
  const track = document.getElementById('sponsorMarqueeTrack');
  if (!track) return;
  const list = [...(appState.sponsors || DEFAULT_SPONSORS), ...(appState.sponsors || DEFAULT_SPONSORS)];
  track.innerHTML = list.map(sp => `
    <a href="${sp.url && sp.url !== '#' ? sp.url : 'javascript:void(0)'}" target="${sp.url && sp.url !== '#' ? '_blank' : '_self'}" class="sponsor-item-mini" rel="noopener">
      <img src="${sp.logo}" alt="${sp.name}" title="${sp.name}">
    </a>
  `).join('');
}

function renderFooterSponsors() {
  const container = document.getElementById('footerSponsorsGrid');
  if (!container) return;
  const list = appState.sponsors || DEFAULT_SPONSORS;
  container.innerHTML = list.map(sp => `
    <a href="${sp.url && sp.url !== '#' ? sp.url : 'javascript:void(0)'}" target="${sp.url && sp.url !== '#' ? '_blank' : '_self'}" title="${sp.name}" rel="noopener">
      <img src="${sp.logo}" alt="${sp.name}" class="footer-sponsor-img">
    </a>
  `).join('');
}

function renderMainContent() {
  const container = document.getElementById('mainContent');
  if (!container) return;

  switch (appState.currentTab) {
    case 'fixture':
      container.innerHTML = renderFixtureView();
      break;
    case 'standings':
      container.innerHTML = renderStandingsView();
      break;
    case 'cruces':
      container.innerHTML = renderCrucesView();
      break;
    case 'teams':
      container.innerHTML = renderTeamsManagementView();
      break;
    case 'sponsors':
      container.innerHTML = renderSponsorsView();
      break;
    case 'app':
      container.innerHTML = renderAppDownloadView();
      break;
    default:
      container.innerHTML = renderFixtureView();
  }
}

// --------------------------------------------------------------------------
// 1. FIXTURE VIEW
// --------------------------------------------------------------------------

function renderFixtureView() {
  const catData = appState.categoriesData ? appState.categoriesData[appState.currentCategory] : null;
  if (!catData) return '<p style="padding:2rem; text-align:center; color:var(--text-muted);">No hay datos cargados para esta categoría.</p>';

  const isGroups = catData.format === 'groups_cup';
  const fixtures = catData.fixtures || [];
  const numGroups = catData.numGroups || Object.keys(catData.groups || {}).length || 3;
  const isManualGroups = catData.groupsSource === 'manual';

  return `
    <div class="format-banner">
      <div>
        <span style="font-weight: 700; color: var(--text-muted); font-size: 0.85rem; display: block;">Modalidad de Competición:</span>
        <span class="format-badge ${isGroups ? 'groups' : 'general'}">
          ${isGroups ? `🎲 Fase de ${numGroups} Grupos + Copas Oro y Plata${isManualGroups ? ' (Grupos Cargados Manualmente)' : ''}` : '📊 Tabla General Única (Todos contra Todos)'}
        </span>
      </div>
      ${appState.isAdmin ? `
        <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
          <button class="btn-secondary" style="font-size: 0.8rem;" onclick="switchCategoryFormat('${appState.currentCategory}', '${isGroups ? 'general_table' : 'groups_cup'}')">
            🔄 Cambiar a ${isGroups ? 'Tabla General Única' : 'Fase de Grupos + Copas'}
          </button>
          <button class="btn-secondary" style="font-size: 0.8rem;" onclick="openManualGroupsModal()">
            📋 ${isGroups ? 'Editar' : 'Cargar'} Grupos Manualmente
          </button>
          ${isGroups && !isManualGroups ? `
            <button class="btn-primary" style="font-size: 0.8rem;" onclick="startInteractiveGroupDraw()">
              🎲 Re-Sortear Grupos
            </button>
          ` : ''}
        </div>
      ` : ''}
    </div>

    <div class="section-title">
      <div>
        <span>Fixture y Calendario de Partidos</span>
        <span class="badge">Categoría ${appState.currentCategory}</span>
      </div>
    </div>

    ${fixtures.length === 0 ? `
      <div style="background: var(--bg-card); padding: 2rem; text-align: center; border-radius: 12px; margin-top: 1rem; border: 1px dashed var(--border-color);">
        <p style="color: var(--primary-gold); font-weight: 700;">No hay partidos generados aún.</p>
        ${appState.isAdmin ? `
          <div style="display: flex; gap: 0.5rem; justify-content: center; flex-wrap: wrap; margin-top: 1rem;">
            <button class="btn-primary" onclick="startInteractiveGroupDraw()">🎲 Realizar Sorteo Aleatorio</button>
            <button class="btn-secondary" onclick="openManualGroupsModal()">📋 Cargar Grupos Manualmente</button>
          </div>
        ` : ''}
      </div>
    ` : fixtures.map((jornada) => `
      <div class="jornada-controls" style="margin-top: 1.5rem;">
        <span class="jornada-title">Jornada ${jornada.jornadaNumber}</span>
      </div>

      <div class="matches-grid">
        ${(jornada.matches || []).map(m => {
          const homeTeam = getTeamObj(m.home);
          const awayTeam = getTeamObj(m.away);
          const isComuMatch = homeTeam.id === 'comu' || awayTeam.id === 'comu';

          return `
            <div class="match-card ${isComuMatch ? 'is-comu' : ''}">
              <div class="match-header">
                <div style="display: flex; flex-direction: column; gap: 0.15rem;">
                  <span style="font-weight: 800; color: var(--primary-gold);">
                    ${m.group ? `<span class="group-badge-${m.group}">Grupo ${m.group}</span> ` : ''}
                    📅 ${m.dayDate || 'Por definir'} • 🕒 ${m.time || ''}
                  </span>
                  <span style="color: var(--text-muted); font-size: 0.75rem;">📍 ${m.pitch || 'Cancha Comunicaciones'}</span>
                </div>
                <span class="status-pill ${m.status}">
                  ${m.status === 'finished' ? 'Finalizado' : (m.status === 'live' ? '• En Vivo' : 'Programado')}
                </span>
              </div>

              <div class="teams-vs">
                <div class="team-box">
                  <img src="${homeTeam.crest}" class="team-crest" alt="${homeTeam.name}">
                  <span class="team-name">${homeTeam.name}</span>
                </div>

                <div class="score-display">
                  <span class="score-num">${m.homeScore !== null && m.homeScore !== undefined ? m.homeScore : '-'}</span>
                  <span class="score-divider">:</span>
                  <span class="score-num">${m.awayScore !== null && m.awayScore !== undefined ? m.awayScore : '-'}</span>
                </div>

                <div class="team-box">
                  <img src="${awayTeam.crest}" class="team-crest" alt="${awayTeam.name}">
                  <span class="team-name">${awayTeam.name}</span>
                </div>
              </div>

              <div class="match-footer">
                <small style="color: var(--text-muted);">Campeonato Mercedes 2026</small>
                <button class="edit-score-btn" onclick="openScoreModal('${m.id}')">
                  ${appState.isAdmin ? '✏️ Editar Resultado' : '🔒 Iniciar Sesión Admin'}
                </button>
              </div>
            </div>
          `;
        }).join('')}
      </div>
    `).join('')}
  `;
}

// --------------------------------------------------------------------------
// 2. STANDINGS VIEW
// --------------------------------------------------------------------------

function renderStandingsView() {
  const catData = appState.categoriesData ? appState.categoriesData[appState.currentCategory] : null;
  if (!catData) return '<p style="padding:2rem; text-align:center;">No hay datos de posiciones.</p>';

  const isGroups = catData.format === 'groups_cup';

  if (!isGroups) {
    const standings = calculateSingleStandings(appState.currentCategory);
    return `
      <div class="section-title">
        <div>
          <span>Tabla General de Posiciones</span>
          <span class="badge">Categoría ${appState.currentCategory}</span>
        </div>
      </div>
      ${renderStandingsTableMarkup(standings, 'Tabla General Única')}
    `;
  }

  const numGroups = catData.numGroups || Object.keys(catData.groups || {}).length || 3;
  const groupKeys = Object.keys(catData.groups || {}).sort();
  const groupColors = { A: 'var(--primary-gold)', B: '#38bdf8', C: '#a855f7' };
  const ranking = calculateQualifiedTeamsRanking(appState.currentCategory);
  const isCross = numGroups === 2;

  return `
    <div class="section-title">
      <div>
        <span>Tablas de Posiciones por Grupos</span>
        <span class="badge">Categoría ${appState.currentCategory}</span>
      </div>
      <button class="btn-primary" onclick="selectTab('cruces')">⚡ Ver Cruces y Copas</button>
    </div>

    <div class="groups-grid">
      ${groupKeys.map(g => `
        <div class="group-card">
          <h3 style="color: ${groupColors[g] || '#fff'}; margin-bottom: 0.75rem; display: flex; justify-content: space-between; align-items: center;">
            <span>🏆 GRUPO ${g}</span>
            <span class="group-badge-${g}">Grupo ${g}</span>
          </h3>
          ${renderGroupMiniTable(calculateGroupStandings(appState.currentCategory, g))}
        </div>
      `).join('')}
    </div>

    <div class="table-card" style="margin-top: 2rem;">
      <div style="padding: 1.25rem; border-bottom: 1px solid var(--border-color); background: rgba(255,215,0,0.05);">
        <h3 style="color: var(--primary-gold); font-size: 1.15rem; font-weight: 900; text-transform: uppercase;">
          ⭐ Ranking General & Clasificados a la Ronda Final (${(catData.teams || []).length} Equipos)
        </h3>
        <p style="color: var(--text-muted); font-size: 0.85rem; margin-top: 0.25rem;">
          ${isCross
            ? 'Pasan los 4 equipos de cada grupo. Se cruzan entre grupos: 1° vs 4°, y 2° vs 3°.'
            : 'Clasifican los 3 Primeros, los 3 Segundos y los 2 Mejores Terceros de la Fase de Grupos.'}
        </p>
      </div>

      <div class="standings-table-wrapper">
        <table class="standings-table">
          <thead>
            <tr>
              <th style="text-align: left; padding-left: 1rem;">Mérito / Condición</th>
              <th>Equipo Clasificado</th>
              <th>Grupo Orig.</th>
              <th>PTS</th>
              <th>DG</th>
              <th>GF</th>
              <th>Destino en Cruces</th>
            </tr>
          </thead>
          <tbody>
            ${(ranking.qualifiedList || []).map((item, idx) => {
              const t = item.team;
              if (!t) return `<tr><td colspan="7" style="text-align:center; color:var(--text-muted);">${item.rankLabel}: Por definir</td></tr>`;
              const isTercero = !isCross && idx >= 6;

              let matchLabel = item.matchLabel || '';
              if (!isCross && !matchLabel) {
                if (idx === 0) matchLabel = 'vs 2° Mejor Tercero (Cruce 1)';
                if (idx === 1) matchLabel = 'vs 1er Mejor Tercero (Cruce 2)';
                if (idx === 2) matchLabel = 'vs Peor Segundo (Cruce 3)';
                if (idx === 3) matchLabel = 'vs 2do Mejor Segundo (Cruce 4)';
                if (idx === 4) matchLabel = 'vs 1er Mejor Segundo (Cruce 4)';
                if (idx === 5) matchLabel = 'vs 3er Mejor Primero (Cruce 3)';
                if (idx === 6) matchLabel = 'vs 2do Mejor Primero (Cruce 2)';
                if (idx === 7) matchLabel = 'vs 1er Mejor Primero (Cruce 1)';
              }

              return `
                <tr class="${isTercero ? 'tr-qualify-tercero' : 'tr-qualify-oro'}">
                  <td style="font-weight: 800; color: var(--primary-gold); padding-left: 1rem;">${item.rankLabel}</td>
                  <td class="team-cell">
                    <img src="${t.crest}" style="width: 26px; height: 26px; object-fit: contain;">
                    <span>${t.name}</span>
                  </td>
                  <td><span class="group-badge-${t.group}">Gr. ${t.group}</span></td>
                  <td class="pts-col">${t.pts}</td>
                  <td>${t.dg > 0 ? '+' + t.dg : t.dg}</td>
                  <td>${t.gf}</td>
                  <td style="font-size: 0.8rem; font-weight: 700; color: var(--text-main);">${matchLabel}</td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function renderGroupMiniTable(standings) {
  if (!standings || standings.length === 0) return '<p style="color:var(--text-muted); font-size:0.85rem;">Esperando partidos...</p>';

  return `
    <table class="standings-table" style="font-size: 0.85rem;">
      <thead>
        <tr>
          <th style="text-align: left;">Equipo</th>
          <th>PTS</th>
          <th>PJ</th>
          <th>DG</th>
        </tr>
      </thead>
      <tbody>
        ${standings.map((t, idx) => `
          <tr style="${idx < 2 ? 'background: rgba(255,215,0,0.06);' : ''}">
            <td class="team-cell">
              <span style="font-weight: 800; width: 18px; color: var(--text-muted);">${idx + 1}°</span>
              <img src="${t.crest}" style="width: 22px; height: 22px; object-fit: contain;">
              <span style="font-weight: 600;">${t.short || t.name}</span>
            </td>
            <td class="pts-col">${t.pts}</td>
            <td>${t.pj}</td>
            <td>${t.dg > 0 ? '+' + t.dg : t.dg}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
}

function renderStandingsTableMarkup(standings, title) {
  return `
    <div class="table-card">
      <div class="standings-table-wrapper">
        <table class="standings-table">
          <thead>
            <tr>
              <th style="text-align: left; padding-left: 1rem;">Equipo</th>
              <th>PTS</th>
              <th>PJ</th>
              <th>PG</th>
              <th>PE</th>
              <th>PP</th>
              <th>GF</th>
              <th>GC</th>
              <th>DG</th>
            </tr>
          </thead>
          <tbody>
            ${(standings || []).map((t, idx) => `
              <tr style="${t.id === 'comu' ? 'background: rgba(255, 215, 0, 0.08); font-weight: bold;' : ''}">
                <td class="team-cell">
                  <span class="pos-badge ${idx === 0 ? 'pos-1' : (idx === 1 ? 'pos-2' : (idx === 2 ? 'pos-3' : ''))}">${idx + 1}</span>
                  <img src="${t.crest}" style="width: 28px; height: 28px; object-fit: contain;">
                  <span>${t.name} ${t.id === 'comu' ? '⭐' : ''}</span>
                </td>
                <td class="pts-col">${t.pts}</td>
                <td>${t.pj}</td>
                <td>${t.pg}</td>
                <td>${t.pe}</td>
                <td>${t.pp}</td>
                <td>${t.gf}</td>
                <td>${t.gc}</td>
                <td>${t.dg > 0 ? '+' + t.dg : t.dg}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

// --------------------------------------------------------------------------
// 3. CRUCES & COPAS ORO / PLATA VIEW
// --------------------------------------------------------------------------

function renderCrucesView() {
  const catData = appState.categoriesData ? appState.categoriesData[appState.currentCategory] : null;
  if (!catData) return '<p style="padding:2rem; text-align:center;">No hay datos de cruces.</p>';

  const isGroups = catData.format === 'groups_cup';

  if (!isGroups) {
    return renderCrucesSingleTableMarkup();
  }

  const numGroups = catData.numGroups || Object.keys(catData.groups || {}).length || 3;
  const ranking = calculateQualifiedTeamsRanking(appState.currentCategory);
  const playoffs = catData.playoffs || createEmptyPlayoffsObj(numGroups);
  catData.playoffs = playoffs;

  if (numGroups === 2) {
    // 2 grupos: cruces directos 1°vs4° y 2°vs3° cruzando grupos (ver ranking.cruces)
    if (playoffs.initialCruces && playoffs.initialCruces.length >= 4 && ranking.cruces) {
      ranking.cruces.forEach((c, i) => {
        if (playoffs.initialCruces[i]) {
          playoffs.initialCruces[i].home = playoffs.initialCruces[i].home || c.home;
          playoffs.initialCruces[i].away = playoffs.initialCruces[i].away || c.away;
        }
      });
    }
  } else {
    const p1_1 = ranking.qualifiedList[0] ? ranking.qualifiedList[0].team : null;
    const p1_2 = ranking.qualifiedList[1] ? ranking.qualifiedList[1].team : null;
    const p1_3 = ranking.qualifiedList[2] ? ranking.qualifiedList[2].team : null;
    const p2_1 = ranking.qualifiedList[3] ? ranking.qualifiedList[3].team : null;
    const p2_2 = ranking.qualifiedList[4] ? ranking.qualifiedList[4].team : null;
    const p2_3 = ranking.qualifiedList[5] ? ranking.qualifiedList[5].team : null;
    const p3_1 = ranking.qualifiedList[6] ? ranking.qualifiedList[6].team : null;
    const p3_2 = ranking.qualifiedList[7] ? ranking.qualifiedList[7].team : null;

    if (playoffs.initialCruces && playoffs.initialCruces.length >= 4) {
      playoffs.initialCruces[0].home = playoffs.initialCruces[0].home || (p1_1 ? p1_1.id : null);
      playoffs.initialCruces[0].away = playoffs.initialCruces[0].away || (p3_2 ? p3_2.id : null);

      playoffs.initialCruces[1].home = playoffs.initialCruces[1].home || (p1_2 ? p1_2.id : null);
      playoffs.initialCruces[1].away = playoffs.initialCruces[1].away || (p3_1 ? p3_1.id : null);

      playoffs.initialCruces[2].home = playoffs.initialCruces[2].home || (p1_3 ? p1_3.id : null);
      playoffs.initialCruces[2].away = playoffs.initialCruces[2].away || (p2_3 ? p2_3.id : null);

      playoffs.initialCruces[3].home = playoffs.initialCruces[3].home || (p2_1 ? p2_1.id : null);
      playoffs.initialCruces[3].away = playoffs.initialCruces[3].away || (p2_2 ? p2_2.id : null);
    }
  }

  return `
    <div class="section-title">
      <div>
        <span>Cruces Iniciales & Fases Finales (Copa Oro / Plata)</span>
        <span class="badge">Categoría ${appState.currentCategory}</span>
      </div>
    </div>

    <div style="background: var(--bg-card); padding: 1.25rem; border-radius: var(--radius-md); border: 1px solid var(--border-color); margin-bottom: 2rem;">
      <h3 style="color: var(--primary-gold); font-size: 1.1rem; font-weight: 900; text-transform: uppercase; margin-bottom: 0.5rem;">
        ⚡ Cruces Iniciales de Clasificación (8 Equipos)
      </h3>
      <p style="color: var(--text-muted); font-size: 0.85rem; margin-bottom: 1.25rem;">
        Los 4 Ganadores clasifican a la <strong>Copa de Oro</strong>. Los 4 Perdedores pasan a la <strong>Copa de Plata</strong>.
      </p>

      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1rem;">
        ${(playoffs.initialCruces || []).map((m, idx) => renderBracketMatchCard(m, `cruce_${idx}`, m.label)).join('')}
      </div>
    </div>

    <div class="cup-header-oro">
      <span>🏆 COPA DE ORO</span>
      ${appState.isAdmin ? `
        <button class="btn-primary" style="font-size: 0.8rem; background: var(--primary-gold); color: #000;" onclick="drawCopaSemis('${appState.currentCategory}', 'oro')">
          🎲 Sortear Semifinales Copa Oro
        </button>
      ` : ''}
    </div>

    <div class="bracket-container">
      <div class="bracket-round">
        <div class="round-header" style="border-color: var(--primary-gold); color: var(--primary-gold);">Semifinales Copa de Oro</div>
        ${(playoffs.oroSemis || []).map((m, idx) => renderBracketMatchCard(m, `oro_semi_${idx}`, `Semi Oro ${idx + 1}`)).join('')}
      </div>

      <div class="bracket-round">
        <div class="round-header" style="background: rgba(255, 215, 0, 0.2); border-color: var(--primary-gold);">👑 GRAN FINAL COPA DE ORO</div>
        ${playoffs.oroFinal ? renderBracketMatchCard(playoffs.oroFinal, 'oro_final', 'Gran Final Oro') : '<p style="padding:1rem;">Por definir</p>'}

        <div class="round-header" style="margin-top: 1.5rem;">🥉 3er Puesto Copa de Oro</div>
        ${playoffs.oroThird ? renderBracketMatchCard(playoffs.oroThird, 'oro_third', '3er Puesto Oro') : '<p style="padding:1rem;">Por definir</p>'}
      </div>
    </div>

    ${playoffs.oroFinal && playoffs.oroFinal.winner ? `
      <div class="champion-card">
        <div class="champion-trophy">🏆</div>
        <h2 style="color: var(--primary-gold); font-weight: 900; text-transform: uppercase;">¡CAMPEÓN COPA DE ORO - CAT. ${appState.currentCategory}!</h2>
        <h1 style="font-size: 2.2rem; color: #fff; margin-top: 0.5rem;">${getTeamName(playoffs.oroFinal.winner)}</h1>
      </div>
    ` : ''}

    <div class="cup-header-plata">
      <span>🥈 COPA DE PLATA</span>
      ${appState.isAdmin ? `
        <button class="btn-secondary" style="font-size: 0.8rem;" onclick="drawCopaSemis('${appState.currentCategory}', 'plata')">
          🎲 Sortear Semifinales Copa Plata
        </button>
      ` : ''}
    </div>

    <div class="bracket-container">
      <div class="bracket-round">
        <div class="round-header" style="border-color: #9ca3af; color: #e5e7eb;">Semifinales Copa de Plata</div>
        ${(playoffs.plataSemis || []).map((m, idx) => renderBracketMatchCard(m, `plata_semi_${idx}`, `Semi Plata ${idx + 1}`)).join('')}
      </div>

      <div class="bracket-round">
        <div class="round-header" style="background: rgba(156, 163, 175, 0.2); border-color: #9ca3af;">🥈 GRAN FINAL COPA DE PLATA</div>
        ${playoffs.plataFinal ? renderBracketMatchCard(playoffs.plataFinal, 'plata_final', 'Gran Final Plata') : '<p style="padding:1rem;">Por definir</p>'}

        <div class="round-header" style="margin-top: 1.5rem;">🥉 3er Puesto Copa de Plata</div>
        ${playoffs.plataThird ? renderBracketMatchCard(playoffs.plataThird, 'plata_third', '3er Puesto Plata') : '<p style="padding:1rem;">Por definir</p>'}
      </div>
    </div>

    ${playoffs.plataFinal && playoffs.plataFinal.winner ? `
      <div class="champion-card" style="border-color: #9ca3af;">
        <div class="champion-trophy">🥈</div>
        <h2 style="color: #e5e7eb; font-weight: 900; text-transform: uppercase;">¡CAMPEÓN COPA DE PLATA - CAT. ${appState.currentCategory}!</h2>
        <h1 style="font-size: 2.2rem; color: #fff; margin-top: 0.5rem;">${getTeamName(playoffs.plataFinal.winner)}</h1>
      </div>
    ` : ''}
  `;
}

function renderCrucesSingleTableMarkup() {
  const catData = appState.categoriesData ? appState.categoriesData[appState.currentCategory] : null;
  const playoffs = catData ? catData.playoffs || createEmptyPlayoffsObj() : createEmptyPlayoffsObj();

  return `
    <div class="section-title">
      <div>
        <span>Cruces Directos y Final</span>
        <span class="badge">Categoría ${appState.currentCategory}</span>
      </div>
    </div>

    <div class="bracket-actions">
      <button class="btn-primary" onclick="generatePlayoffsFromSingleTable()">
        🔄 Generar Cruces por Tabla General
      </button>
    </div>

    <div class="bracket-container" style="margin-top: 1.5rem;">
      <div class="bracket-round">
        <div class="round-header">Semifinales</div>
        ${(playoffs.oroSemis || []).map((m, idx) => renderBracketMatchCard(m, `oro_semi_${idx}`, `Semi ${idx + 1}`)).join('')}
      </div>

      <div class="bracket-round">
        <div class="round-header" style="background: rgba(255, 215, 0, 0.2); border-color: var(--primary-gold);">🏆 Gran Final</div>
        ${playoffs.oroFinal ? renderBracketMatchCard(playoffs.oroFinal, 'oro_final', 'Gran Final') : '<p>Por definir</p>'}
      </div>
    </div>
  `;
}

function renderBracketMatchCard(m, matchTypeKey, titleLabel) {
  if (!m) return '';
  const home = getTeamObj(m.home);
  const away = getTeamObj(m.away);

  return `
    <div class="bracket-match">
      <div style="background: rgba(0,0,0,0.5); padding: 0.35rem 0.65rem; font-size: 0.75rem; color: var(--primary-gold); font-weight: 800; border-bottom: 1px solid rgba(255,255,255,0.05); display: flex; justify-content: space-between; flex-wrap: wrap; gap: 0.25rem;">
        <span>${titleLabel}</span>
        <span>${m.dayDate || 'Por definir'}${m.pitch ? ' • 🏟️ ' + m.pitch : ''}</span>
      </div>

      <div class="bracket-team ${m.winner === m.home && m.home ? 'winner' : ''}">
        <div style="display: flex; align-items: center; gap: 0.5rem;">
          <img src="${home.crest}" style="width: 24px; height: 24px; object-fit: contain;">
          <span style="font-weight: 700;">${home.name}</span>
        </div>
        <span class="bracket-score">${m.homeScore !== null && m.homeScore !== undefined ? m.homeScore : '-'}</span>
      </div>

      <div class="bracket-team ${m.winner === m.away && m.away ? 'winner' : ''}">
        <div style="display: flex; align-items: center; gap: 0.5rem;">
          <img src="${away.crest}" style="width: 24px; height: 24px; object-fit: contain;">
          <span style="font-weight: 700;">${away.name}</span>
        </div>
        <span class="bracket-score">${m.awayScore !== null && m.awayScore !== undefined ? m.awayScore : '-'}</span>
      </div>

      <div style="padding: 0.4rem; background: rgba(0,0,0,0.4); text-align: center;">
        <button class="edit-score-btn" style="margin: 0 auto; font-size: 0.75rem; width: 100%; justify-content: center;" onclick="openPlayoffScoreModal('${matchTypeKey}')">
          ${appState.isAdmin ? '✏️ Definir Resultado' : '🔒 Iniciar Sesión Admin'}
        </button>
      </div>
    </div>
  `;
}

// --------------------------------------------------------------------------
// 4. TEAMS MANAGEMENT VIEW
// --------------------------------------------------------------------------

function renderTeamsManagementView() {
  const catData = appState.categoriesData ? appState.categoriesData[appState.currentCategory] : null;
  if (!catData) return '';

  const teamList = catData.teams || [];

  return `
    <div class="section-title">
      <div>
        <span>Equipos Registrados (${teamList.length} Equipos)</span>
        <span class="badge">Categoría ${appState.currentCategory}</span>
      </div>
      ${appState.isAdmin ? `
        <button class="btn-primary" onclick="openAddTeamModal()">+ Cargar Nuevo Equipo</button>
      ` : `
        <button class="btn-secondary" style="font-size: 0.8rem;" onclick="openAdminPinModal()">🔒 Iniciar Sesión Admin</button>
      `}
    </div>

    <p style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 1.25rem;">
      Puedes cargar manualmente la cantidad de equipos deseada para la categoría ${appState.currentCategory} y subir sus respectivos escudos.
    </p>

    <div class="teams-manage-grid">
      ${teamList.map(t => `
        <div class="team-manage-card">
          <img src="${t.crest || OFFICIAL_COMU_CREST}" style="width: 56px; height: 56px; object-fit: contain;">
          <h4 style="font-weight: 800; font-size: 0.95rem; color: #fff;">${t.name}</h4>
          <span style="font-size: 0.75rem; color: var(--primary-gold); font-weight: 900;">Sigla: ${t.short || '-'}</span>

          ${appState.isAdmin ? `
            <div style="display: flex; gap: 0.5rem; width: 100%; margin-top: 0.5rem;">
              <button class="btn-secondary" style="flex: 1; font-size: 0.75rem; padding: 0.35rem;" onclick="openEditTeamModal('${t.id}')">✏️ Editar</button>
              ${!t.isHost ? `
                <button class="btn-secondary" style="color: #ef4444; border-color: rgba(239,68,68,0.3); font-size: 0.75rem; padding: 0.35rem;" onclick="deleteTeamFromCategory('${t.id}')">🗑️</button>
              ` : ''}
            </div>
          ` : ''}
        </div>
      `).join('')}
    </div>
  `;
}

// --------------------------------------------------------------------------
// INTERACTIVE GROUPS DRAW ANIMATION MODAL
// --------------------------------------------------------------------------

function startInteractiveGroupDraw() {
  if (!appState.isAdmin) return openAdminPinModal();

  const catData = appState.categoriesData ? appState.categoriesData[appState.currentCategory] : null;
  if (!confirmOverwriteIfNeeded(appState.currentCategory, catData)) return;

  const modal = document.getElementById('drawModal');
  const stage = document.getElementById('drawStageContent');
  if (!modal || !stage) return;

  modal.classList.add('open');

  stage.innerHTML = `
    <div class="draw-bowl-box">
      <div class="draw-ball-spinning">⚽</div>
      <h3 style="color: var(--primary-gold); font-weight: 900;">¡Sorteando Grupos A, B y C!</h3>
      <p style="color: var(--text-muted); margin-top: 0.5rem;">Mezclando los bolilleros de la Categoría ${appState.currentCategory}...</p>
    </div>
    <button class="btn-primary" style="margin-top: 1rem; width: 100%; justify-content: center;" onclick="revealGroupDrawLive()">
      🎲 Iniciar Sorteo en Vivo
    </button>
  `;
}

function revealGroupDrawLive() {
  const catYear = appState.currentCategory;
  executeGroupDrawBackend(catYear, true);

  const catData = appState.categoriesData ? appState.categoriesData[catYear] : null;
  const stage = document.getElementById('drawStageContent');
  if (!catData || !stage) return;

  const groupKeys = Object.keys(catData.groups || {}).sort();
  const groupColors = { A: 'var(--primary-gold)', B: '#38bdf8', C: '#a855f7' };
  const groupBg = { A: 'rgba(255,215,0,0.1)', B: 'rgba(56,189,248,0.1)', C: 'rgba(168,85,247,0.1)' };

  stage.innerHTML = `
    <div style="text-align: center;">
      <h2 style="color: var(--primary-gold); font-weight: 900;">🎉 ¡SORTEO COMPLETADO EXITOSAMENTE!</h2>
      <p style="color: var(--text-muted); margin-bottom: 1.5rem;">Los equipos se organizaron automáticamente en ${groupKeys.length} Grupos:</p>

      <div style="display: grid; grid-template-columns: repeat(${groupKeys.length}, 1fr); gap: 0.75rem; text-align: left; margin-bottom: 1.5rem;">
        ${groupKeys.map(g => `
          <div style="background: ${groupBg[g] || 'rgba(255,255,255,0.05)'}; padding: 0.75rem; border-radius: 8px; border: 1px solid ${groupColors[g] || '#fff'};">
            <h4 style="color: ${groupColors[g] || '#fff'}; font-weight: 900;">GRUPO ${g}</h4>
            <ul style="padding-left: 1rem; font-size: 0.85rem; margin-top: 0.5rem;">
              ${(catData.groups[g] || []).map(id => `<li>${getTeamName(id)}</li>`).join('')}
            </ul>
          </div>
        `).join('')}
      </div>

      <button class="btn-primary" style="width: 100%; justify-content: center;" onclick="closeDrawModal()">
        ✅ Ver Fixture y Grupos
      </button>
    </div>
  `;
  safeRenderApp();
}

function closeDrawModal() {
  const modal = document.getElementById('drawModal');
  if (modal) modal.classList.remove('open');
}

// --------------------------------------------------------------------------
// CARGA MANUAL DE GRUPOS (sorteo ya realizado fuera del sistema, sin azar)
// --------------------------------------------------------------------------

let manualGroupsDraft = { numGroups: 3, assignment: {} };

function openManualGroupsModal() {
  if (!appState.isAdmin) return openAdminPinModal();
  const catData = appState.categoriesData ? appState.categoriesData[appState.currentCategory] : null;
  if (!catData) return;

  const modal = document.getElementById('manualGroupsModal');
  const content = document.getElementById('manualGroupsContent');
  if (!modal || !content) return;

  const currentNumGroups = catData.numGroups || Object.keys(catData.groups || {}).length || 3;
  const groupsObj = catData.groups || {};
  const assignment = {};
  (catData.teams || []).forEach(t => {
    let currentGroup = '';
    Object.keys(groupsObj).forEach(g => {
      if ((groupsObj[g] || []).includes(t.id)) currentGroup = g;
    });
    assignment[t.id] = currentGroup;
  });

  manualGroupsDraft = { numGroups: currentNumGroups, assignment: assignment };

  content.innerHTML = renderManualGroupsModalContent(catData);
  modal.classList.add('open');
}

function renderManualGroupsModalContent(catData) {
  const letters = generateGroupLetters(manualGroupsDraft.numGroups);
  return `
    <p style="color: var(--text-muted); font-size: 0.85rem; margin-bottom: 1rem;">
      Cargá a mano en qué grupo quedó cada equipo según el sorteo ya realizado (sin generar un sorteo aleatorio nuevo).
      El fixture de la fase de grupos se arma automáticamente en base a esta carga.
    </p>

    <div class="form-group">
      <label>Cantidad de Grupos</label>
      <select class="form-input" onchange="changeManualGroupsCount(this.value)">
        <option value="2" ${manualGroupsDraft.numGroups === 2 ? 'selected' : ''}>2 Grupos (equipos incompletos)</option>
        <option value="3" ${manualGroupsDraft.numGroups === 3 ? 'selected' : ''}>3 Grupos (formato estándar 12 equipos)</option>
      </select>
    </div>

    <div style="max-height: 320px; overflow-y: auto; margin-top: 1rem;">
      ${(catData.teams || []).map(t => `
        <div style="display: flex; align-items: center; justify-content: space-between; gap: 0.75rem; padding: 0.5rem 0; border-bottom: 1px solid var(--border-color);">
          <span style="font-weight: 700; font-size: 0.9rem;">${t.name}</span>
          <select class="form-input" style="max-width: 160px;" onchange="setManualGroupAssignment('${t.id}', this.value)">
            <option value="">Sin asignar</option>
            ${letters.map(l => `<option value="${l}" ${manualGroupsDraft.assignment[t.id] === l ? 'selected' : ''}>Grupo ${l}</option>`).join('')}
          </select>
        </div>
      `).join('')}
    </div>

    <div style="display: flex; gap: 0.75rem; margin-top: 1.5rem;">
      <button class="btn-secondary" style="flex: 1; justify-content: center;" onclick="closeManualGroupsModal()">Cancelar</button>
      <button class="btn-primary" style="flex: 1; justify-content: center;" onclick="saveManualGroups()">Guardar Grupos y Generar Fixture</button>
    </div>
  `;
}

function changeManualGroupsCount(val) {
  const catData = appState.categoriesData ? appState.categoriesData[appState.currentCategory] : null;
  if (!catData) return;
  const numGroups = parseInt(val, 10);
  manualGroupsDraft.numGroups = numGroups;

  const letters = generateGroupLetters(numGroups);
  Object.keys(manualGroupsDraft.assignment).forEach(tid => {
    if (manualGroupsDraft.assignment[tid] && letters.indexOf(manualGroupsDraft.assignment[tid]) === -1) {
      manualGroupsDraft.assignment[tid] = '';
    }
  });

  const content = document.getElementById('manualGroupsContent');
  if (content) content.innerHTML = renderManualGroupsModalContent(catData);
}

function setManualGroupAssignment(teamId, groupLetter) {
  manualGroupsDraft.assignment[teamId] = groupLetter;
}

function saveManualGroups() {
  if (!appState.isAdmin) return;
  const catYear = appState.currentCategory;
  const catData = appState.categoriesData ? appState.categoriesData[catYear] : null;
  if (!catData) return;

  const numGroups = manualGroupsDraft.numGroups;
  const letters = generateGroupLetters(numGroups);
  const groups = {};
  letters.forEach(l => { groups[l] = []; });

  let unassignedCount = 0;
  (catData.teams || []).forEach(t => {
    const g = manualGroupsDraft.assignment[t.id];
    if (g && groups[g]) {
      groups[g].push(t.id);
    } else {
      unassignedCount++;
    }
  });

  if (unassignedCount > 0) {
    if (!confirm(`Hay ${unassignedCount} equipo(s) sin asignar a un grupo. ¿Confirmás que querés guardar así de todas formas?`)) return;
  }

  const hasProgress = categoryHasRealProgress(catData);
  if (hasProgress) {
    if (!confirm('Ya hay partidos EN VIVO o FINALIZADOS cargados en esta categoría. Guardar los grupos ahora va a REGENERAR todo el fixture de la fase de grupos y esos resultados se perderían. ¿Confirmás que querés continuar?')) return;
  }

  catData.groups = groups;
  catData.numGroups = numGroups;
  catData.format = 'groups_cup';
  catData.groupsSource = 'manual';
  catData.fixtures = generateGroupsFixtures(groups, catYear);
  catData.playoffs = createEmptyPlayoffsObj(numGroups);

  saveState();
  closeManualGroupsModal();
  safeRenderApp();
  alert('Grupos cargados y fixture generado correctamente.');
}

function closeManualGroupsModal() {
  const modal = document.getElementById('manualGroupsModal');
  if (modal) modal.classList.remove('open');
}

// --------------------------------------------------------------------------
// SEMIFINALS DRAW LOGIC (COPA ORO / PLATA)
// --------------------------------------------------------------------------

function drawCopaSemis(category, cupType) {
  if (!appState.isAdmin) return openAdminPinModal();

  const catData = appState.categoriesData ? appState.categoriesData[category] : null;
  if (!catData) return;

  const playoffs = catData.playoffs || createEmptyPlayoffsObj();
  catData.playoffs = playoffs;

  const candidates = [];
  (playoffs.initialCruces || []).forEach(m => {
    if (m.winner && m.loser) {
      if (cupType === 'oro') candidates.push(m.winner);
      if (cupType === 'plata') candidates.push(m.loser);
    }
  });

  if (candidates.length < 4) {
    alert(`Se requieren definir los 4 resultados de los Cruces Iniciales para poder sortear las Semifinales de la Copa de ${cupType === 'oro' ? 'Oro' : 'Plata'}.`);
    return;
  }

  const shuffled = [...candidates].sort(() => Math.random() - 0.5);

  if (cupType === 'oro') {
    playoffs.oroSemis[0].home = shuffled[0];
    playoffs.oroSemis[0].away = shuffled[1];
    playoffs.oroSemis[1].home = shuffled[2];
    playoffs.oroSemis[1].away = shuffled[3];
    playoffs.oroDrawn = true;
  } else {
    playoffs.plataSemis[0].home = shuffled[0];
    playoffs.plataSemis[0].away = shuffled[1];
    playoffs.plataSemis[1].home = shuffled[2];
    playoffs.plataSemis[1].away = shuffled[3];
    playoffs.plataDrawn = true;
  }

  saveState();
  safeRenderApp();
  alert(`¡Sorteo de Semifinales de la Copa de ${cupType === 'oro' ? 'Oro' : 'Plata'} realizado exitosamente!`);
}

// --------------------------------------------------------------------------
// TEAM MANAGEMENT MODALS & HANDLERS
// --------------------------------------------------------------------------

function openAddTeamModal() {
  if (!appState.isAdmin) return openAdminPinModal();

  document.getElementById('teamModalTitle').innerText = '➕ Cargar Nuevo Equipo';
  document.getElementById('teamEditId').value = '';
  document.getElementById('teamNameInput').value = '';
  document.getElementById('teamShortInput').value = '';
  document.getElementById('teamFileInput').value = '';
  document.getElementById('teamPresetCrestSelect').value = '';
  document.getElementById('crestPreviewBox').style.display = 'none';

  document.getElementById('teamModal').classList.add('open');
}

function openEditTeamModal(teamId) {
  if (!appState.isAdmin) return openAdminPinModal();

  const team = getTeamObj(teamId);
  if (!team) return;

  document.getElementById('teamModalTitle').innerText = '✏️ Editar Equipo';
  document.getElementById('teamEditId').value = team.id;
  document.getElementById('teamNameInput').value = team.name;
  document.getElementById('teamShortInput').value = team.short || '';
  document.getElementById('teamFileInput').value = '';
  document.getElementById('teamPresetCrestSelect').value = '';

  const previewImg = document.getElementById('crestPreviewImg');
  previewImg.src = team.crest || OFFICIAL_COMU_CREST;
  document.getElementById('crestPreviewBox').style.display = 'block';

  document.getElementById('teamModal').classList.add('open');
}

function previewPresetCrest() {
  const presetKey = document.getElementById('teamPresetCrestSelect').value;
  const previewBox = document.getElementById('crestPreviewBox');
  const previewImg = document.getElementById('crestPreviewImg');

  if (presetKey && TEAM_CRESTS[presetKey]) {
    previewImg.src = TEAM_CRESTS[presetKey];
    previewBox.style.display = 'block';
  } else {
    previewBox.style.display = 'none';
  }
}

function saveTeamForm() {
  if (!appState.isAdmin) return;

  const catData = appState.categoriesData ? appState.categoriesData[appState.currentCategory] : null;
  if (!catData) return;

  const editId = document.getElementById('teamEditId').value;
  const name = document.getElementById('teamNameInput').value.trim();
  const shortName = document.getElementById('teamShortInput').value.trim().toUpperCase();
  const presetKey = document.getElementById('teamPresetCrestSelect').value;
  const fileInput = document.getElementById('teamFileInput');

  if (!name) {
    alert('Ingresa el nombre del equipo.');
    return;
  }

  const processSave = (crestDataUrl) => {
    let finalCrest = crestDataUrl;
    if (!finalCrest && presetKey && TEAM_CRESTS[presetKey]) {
      finalCrest = TEAM_CRESTS[presetKey];
    }

    if (editId) {
      const target = (catData.teams || []).find(t => t.id === editId);
      if (target) {
        target.name = name;
        target.short = shortName || name.substring(0, 3).toUpperCase();
        if (finalCrest) target.crest = finalCrest;
      }
    } else {
      const newId = 't_' + Date.now();
      catData.teams = catData.teams || [];
      catData.teams.push({
        id: newId,
        name: name,
        short: shortName || name.substring(0, 3).toUpperCase(),
        crest: finalCrest || OFFICIAL_COMU_CREST,
        isHost: false
      });
    }

    saveState();
    closeTeamModal();
    safeRenderApp();
  };

  if (fileInput.files && fileInput.files[0]) {
    resizeImageToDataURL(fileInput.files[0], 220, 0.72)
      .then(processSave)
      .catch((err) => {
        console.error(err);
        alert('No se pudo procesar la imagen del escudo. Probá con otra imagen.');
      });
  } else {
    processSave(null);
  }
}

function deleteTeamFromCategory(teamId) {
  if (!appState.isAdmin) return openAdminPinModal();

  if (confirm('¿Deseas eliminar este equipo de la categoría?')) {
    const catData = appState.categoriesData ? appState.categoriesData[appState.currentCategory] : null;
    if (catData && catData.teams) {
      catData.teams = catData.teams.filter(t => t.id !== teamId);
      saveState();
      safeRenderApp();
    }
  }
}

function closeTeamModal() {
  const modal = document.getElementById('teamModal');
  if (modal) modal.classList.remove('open');
}

// --------------------------------------------------------------------------
// PLAYOFF SCORES HANDLERS & MODALS
// --------------------------------------------------------------------------

let currentPlayoffMatchKey = null;

function openPlayoffScoreModal(matchKey) {
  if (!appState.isAdmin) return openAdminPinModal();

  currentPlayoffMatchKey = matchKey;
  const catData = appState.categoriesData ? appState.categoriesData[appState.currentCategory] : null;
  if (!catData) return;

  const playoffs = catData.playoffs || createEmptyPlayoffsObj();
  const matchObj = findPlayoffMatchObj(playoffs, matchKey);

  if (!matchObj || (!matchObj.home && !matchObj.away)) {
    alert('Primero se deben definir los equipos clasificados a este encuentro.');
    return;
  }

  const home = getTeamObj(matchObj.home);
  const away = getTeamObj(matchObj.away);

  document.getElementById('modalPlayoffHomeName').innerText = home.name;
  document.getElementById('modalPlayoffAwayName').innerText = away.name;
  document.getElementById('modalPlayoffHomeInput').value = matchObj.homeScore !== null && matchObj.homeScore !== undefined ? matchObj.homeScore : 0;
  document.getElementById('modalPlayoffAwayInput').value = matchObj.awayScore !== null && matchObj.awayScore !== undefined ? matchObj.awayScore : 0;
  document.getElementById('modalPlayoffDayDateInput').value = matchObj.dayDate || '';
  document.getElementById('modalPlayoffPitchInput').value = matchObj.pitch || '';

  document.getElementById('playoffScoreModal').classList.add('open');
}

function findPlayoffMatchObj(playoffs, matchKey) {
  if (matchKey.startsWith('cruce_')) {
    const idx = parseInt(matchKey.split('_')[1], 10);
    return (playoffs.initialCruces || [])[idx];
  } else if (matchKey.startsWith('oro_semi_')) {
    const idx = parseInt(matchKey.split('_')[2], 10);
    return (playoffs.oroSemis || [])[idx];
  } else if (matchKey === 'oro_final') {
    return playoffs.oroFinal;
  } else if (matchKey === 'oro_third') {
    return playoffs.oroThird;
  } else if (matchKey.startsWith('plata_semi_')) {
    const idx = parseInt(matchKey.split('_')[2], 10);
    return (playoffs.plataSemis || [])[idx];
  } else if (matchKey === 'plata_final') {
    return playoffs.plataFinal;
  } else if (matchKey === 'plata_third') {
    return playoffs.plataThird;
  }
  return null;
}

// Guarda solo día/horario y cancha del cruce, sin tocar resultado/ganador.
// Útil para fijar (o corregir) el horario ya informado sin forzar una definición de ganador.
function savePlayoffSchedule() {
  if (!appState.isAdmin || !currentPlayoffMatchKey) return;

  const catData = appState.categoriesData ? appState.categoriesData[appState.currentCategory] : null;
  if (!catData) return;

  const playoffs = catData.playoffs || createEmptyPlayoffsObj();
  const matchObj = findPlayoffMatchObj(playoffs, currentPlayoffMatchKey);

  if (matchObj) {
    matchObj.dayDate = document.getElementById('modalPlayoffDayDateInput').value.trim();
    matchObj.pitch = document.getElementById('modalPlayoffPitchInput').value.trim();
  }

  saveState();
  closePlayoffScoreModal();
  safeRenderApp();
}

function savePlayoffScore() {
  if (!appState.isAdmin || !currentPlayoffMatchKey) return;

  const catData = appState.categoriesData ? appState.categoriesData[appState.currentCategory] : null;
  if (!catData) return;

  const playoffs = catData.playoffs || createEmptyPlayoffsObj();
  const homeScore = parseInt(document.getElementById('modalPlayoffHomeInput').value, 10);
  const awayScore = parseInt(document.getElementById('modalPlayoffAwayInput').value, 10);
  const dayDate = document.getElementById('modalPlayoffDayDateInput').value.trim();
  const pitch = document.getElementById('modalPlayoffPitchInput').value.trim();

  const matchObj = findPlayoffMatchObj(playoffs, currentPlayoffMatchKey);

  if (matchObj) {
    matchObj.homeScore = isNaN(homeScore) ? 0 : homeScore;
    matchObj.awayScore = isNaN(awayScore) ? 0 : awayScore;
    matchObj.dayDate = dayDate;
    matchObj.pitch = pitch;

    if (homeScore === awayScore) {
      const choice = prompt(`Empate ${homeScore}-${awayScore}. Elige Ganador por penales (1 para ${getTeamName(matchObj.home)} o 2 para ${getTeamName(matchObj.away)}):`, '1');
      matchObj.winner = choice === '2' ? matchObj.away : matchObj.home;
      matchObj.loser = choice === '2' ? matchObj.home : matchObj.away;
    } else {
      matchObj.winner = homeScore > awayScore ? matchObj.home : matchObj.away;
      matchObj.loser = homeScore > awayScore ? matchObj.away : matchObj.home;
    }

    syncSemisToFinals('oro');
    syncSemisToFinals('plata');
  }

  saveState();
  closePlayoffScoreModal();
  safeRenderApp();
}

function syncSemisToFinals(cupType) {
  const catData = appState.categoriesData ? appState.categoriesData[appState.currentCategory] : null;
  if (!catData || !catData.playoffs) return;

  const playoffs = catData.playoffs;
  const semis = cupType === 'oro' ? playoffs.oroSemis : playoffs.plataSemis;
  const final = cupType === 'oro' ? playoffs.oroFinal : playoffs.plataFinal;
  const third = cupType === 'oro' ? playoffs.oroThird : playoffs.plataThird;

  if (semis && semis[0] && semis[1] && semis[0].winner && semis[1].winner && final && third) {
    final.home = semis[0].winner;
    final.away = semis[1].winner;

    third.home = semis[0].loser;
    third.away = semis[1].loser;
  }
}

function closePlayoffScoreModal() {
  const modal = document.getElementById('playoffScoreModal');
  if (modal) modal.classList.remove('open');
}

// --------------------------------------------------------------------------
// OTHER CONTROLLERS & SPONSORS (PRESERVED)
// --------------------------------------------------------------------------

function getTeamObj(teamId) {
  if (!teamId) return { name: 'Por Definir', crest: OFFICIAL_COMU_CREST };
  const catData = appState.categoriesData ? appState.categoriesData[appState.currentCategory] : null;
  if (!catData || !catData.teams) return { name: teamId, crest: OFFICIAL_COMU_CREST };
  const found = catData.teams.find(t => t.id === teamId);
  return found || { name: teamId, crest: OFFICIAL_COMU_CREST };
}

function getTeamName(teamId) {
  return getTeamObj(teamId).name;
}

function selectCategory(cat) {
  appState.currentCategory = cat;
  saveLocalStateOnly();
  safeRenderApp();
}

function selectTab(tab) {
  appState.currentTab = tab;
  saveLocalStateOnly();
  safeRenderApp();
}

function openAdminPinModal() {
  const emailInput = document.getElementById('adminEmailInput');
  const input = document.getElementById('adminPinInput');
  if (emailInput) emailInput.value = '';
  if (input) input.value = '';
  const modal = document.getElementById('adminPinModal');
  if (modal) modal.classList.add('open');
}

function closeAdminPinModal() {
  const modal = document.getElementById('adminPinModal');
  if (modal) modal.classList.remove('open');
}

function submitAdminPin() {
  const email = (document.getElementById('adminEmailInput').value || '').trim();
  const password = (document.getElementById('adminPinInput').value || '').trim();

  if (!fbAuth) {
    alert('La conexión con Firebase todavía no está lista. Esperá un segundo y volvé a intentar.');
    return;
  }
  if (!email || !password) {
    alert('Ingresá el email y la contraseña de administrador.');
    return;
  }

  fbAuth.signInWithEmailAndPassword(email, password)
    .then(() => {
      closeAdminPinModal();
      // Si la base todavía está vacía, ahora que ya sos admin, sembrá el estado local.
      if (fbSyncReady && (!appState.categoriesData || Object.keys(appState.categoriesData).length === 0)) {
        pushStateToFirebase();
      }
      safeRenderApp();
      alert('¡Sesión de Administrador iniciada correctamente!');
    })
    .catch((err) => {
      console.error(err);
      alert('No se pudo iniciar sesión: email o contraseña incorrectos.');
    });
}

function logoutAdmin() {
  if (!fbAuth) return;
  fbAuth.signOut().then(() => {
    safeRenderApp();
    alert('Has cerrado la sesión de Administrador.');
  });
}

let currentEditingMatchId = null;

function openScoreModal(matchId) {
  if (!appState.isAdmin) return openAdminPinModal();
  currentEditingMatchId = matchId;
  const catData = appState.categoriesData ? appState.categoriesData[appState.currentCategory] : null;
  if (!catData) return;

  let matchObj = null;
  (catData.fixtures || []).forEach(j => {
    const found = (j.matches || []).find(m => m.id === matchId);
    if (found) matchObj = found;
  });

  if (!matchObj) return;

  const catTeams = catData.teams || [];
  const homeSelect = document.getElementById('modalHomeTeamSelect');
  const awaySelect = document.getElementById('modalAwayTeamSelect');
  if (homeSelect) homeSelect.innerHTML = catTeams.map(t => `<option value="${t.id}" ${t.id === matchObj.home ? 'selected' : ''}>${t.name}</option>`).join('');
  if (awaySelect) awaySelect.innerHTML = catTeams.map(t => `<option value="${t.id}" ${t.id === matchObj.away ? 'selected' : ''}>${t.name}</option>`).join('');

  document.getElementById('modalHomeInput').value = matchObj.homeScore !== null && matchObj.homeScore !== undefined ? matchObj.homeScore : 0;
  document.getElementById('modalAwayInput').value = matchObj.awayScore !== null && matchObj.awayScore !== undefined ? matchObj.awayScore : 0;
  document.getElementById('modalStatusSelect').value = matchObj.status;
  
  document.getElementById('modalDayDateInput').value = matchObj.dayDate || '';
  document.getElementById('modalTimeInput').value = matchObj.time || '';
  document.getElementById('modalPitchInput').value = matchObj.pitch || '';

  document.getElementById('scoreModal').classList.add('open');
}

function saveMatchScore() {
  if (!currentEditingMatchId || !appState.isAdmin) return;

  const catData = appState.categoriesData ? appState.categoriesData[appState.currentCategory] : null;
  if (!catData) return;

  const homeScore = parseInt(document.getElementById('modalHomeInput').value, 10);
  const awayScore = parseInt(document.getElementById('modalAwayInput').value, 10);
  const status = document.getElementById('modalStatusSelect').value;

  const homeTeamSelect = document.getElementById('modalHomeTeamSelect');
  const awayTeamSelect = document.getElementById('modalAwayTeamSelect');
  const homeTeamId = homeTeamSelect ? homeTeamSelect.value : null;
  const awayTeamId = awayTeamSelect ? awayTeamSelect.value : null;

  if (homeTeamId && awayTeamId && homeTeamId === awayTeamId) {
    alert('El equipo Local y el Visitante no pueden ser el mismo equipo.');
    return;
  }

  const dayDate = document.getElementById('modalDayDateInput').value.trim();
  const time = document.getElementById('modalTimeInput').value.trim();
  const pitch = document.getElementById('modalPitchInput').value.trim();

  (catData.fixtures || []).forEach(j => {
    const matchObj = (j.matches || []).find(m => m.id === currentEditingMatchId);
    if (matchObj) {
      if (homeTeamId) matchObj.home = homeTeamId;
      if (awayTeamId) matchObj.away = awayTeamId;
      matchObj.homeScore = isNaN(homeScore) ? 0 : homeScore;
      matchObj.awayScore = isNaN(awayScore) ? 0 : awayScore;
      matchObj.status = status;
      matchObj.dayDate = dayDate;
      matchObj.time = time;
      matchObj.pitch = pitch;
    }
  });

  saveState();
  closeScoreModal();
  safeRenderApp();
}

function closeScoreModal() {
  const modal = document.getElementById('scoreModal');
  if (modal) modal.classList.remove('open');
}

// Sponsor Actions
function openAddSponsorModal() {
  if (!appState.isAdmin) return openAdminPinModal();
  const modal = document.getElementById('sponsorModal');
  if (modal) modal.classList.add('open');
}

function closeSponsorModal() {
  const modal = document.getElementById('sponsorModal');
  if (modal) modal.classList.remove('open');
}

function saveSponsor() {
  if (!appState.isAdmin) return;

  const name = document.getElementById('sponsorNameInput').value;
  const tier = document.getElementById('sponsorTierInput').value;
  const url = document.getElementById('sponsorUrlInput').value || '#';
  const fileInput = document.getElementById('sponsorFileInput');

  if (!name) {
    alert('Ingresa el nombre del auspiciante.');
    return;
  }

  const createSponsorObj = (logoUrl) => {
    const newSp = {
      id: 'sp_' + Date.now(),
      name: name,
      tier: tier,
      logo: logoUrl || DEFAULT_SPONSORS[0].logo,
      url: url
    };
    appState.sponsors = appState.sponsors || [];
    appState.sponsors.push(newSp);
    saveState();
    closeSponsorModal();
    safeRenderApp();
  };

  if (fileInput.files && fileInput.files[0]) {
    resizeImageToDataURL(fileInput.files[0], 260, 0.72)
      .then(createSponsorObj)
      .catch((err) => {
        console.error(err);
        alert('No se pudo procesar el logo del sponsor. Probá con otra imagen.');
      });
  } else {
    createSponsorObj(null);
  }
}

function deleteSponsor(spId) {
  if (!appState.isAdmin) return openAdminPinModal();

  if (confirm('¿Deseas eliminar este sponsor?')) {
    appState.sponsors = (appState.sponsors || []).filter(s => s.id !== spId);
    saveState();
    safeRenderApp();
  }
}

function renderSponsorsView() {
  const list = appState.sponsors || DEFAULT_SPONSORS;
  return `
    <div class="section-title">
      <div>
        <span>Auspiciantes y Sponsors Oficiales</span>
        <span class="badge">${list.length} Sponsors Activos</span>
      </div>
      <button class="btn-primary" onclick="openAddSponsorModal()">+ Agregar Auspiciante</button>
    </div>

    <div class="sponsor-admin-grid">
      ${list.map(sp => `
        <div class="sponsor-card-admin">
          <span class="sponsor-tier-badge tier-${sp.tier}">Sponsor ${sp.tier.toUpperCase()}</span>
          <img src="${sp.logo}" alt="${sp.name}" style="max-height: 80px; width: 100%; object-fit: contain;">
          <h4 style="font-weight: 800; font-size: 1rem; margin-top: 0.4rem;">${sp.name}</h4>
          ${appState.isAdmin ? `
            <button class="btn-secondary" style="width: 100%; justify-content: center; font-size: 0.8rem; margin-top: 0.5rem; color: #ef4444; border-color: rgba(239, 68, 68, 0.3);" onclick="deleteSponsor('${sp.id}')">
              🗑️ Eliminar
            </button>
          ` : ''}
        </div>
      `).join('')}
    </div>
  `;
}

function renderAppDownloadView() {
  return `
    <div class="section-title">
      <span>Instalar Aplicación & Panel Administrativo</span>
    </div>

    <div class="pwa-banner">
      <div class="pwa-info">
        <div class="pwa-icon">📱</div>
        <div>
          <h3 style="color: var(--primary-gold); font-weight: 900;">App Móvil Comunicaciones Mercedes</h3>
          <p style="color: var(--text-muted); font-size: 0.85rem;">Instálala en tu celular para ver resultados y posiciones sin gastar datos.</p>
        </div>
      </div>
      <button class="btn-primary" onclick="triggerPwaInstall()">
        📲 Instalar App Ahora
      </button>
    </div>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1.5rem;">
      <div class="table-card" style="padding: 1.5rem;">
        <h3 style="color: var(--primary-gold); margin-bottom: 1rem;">🤖 Instalación en Android (Chrome)</h3>
        <ol style="color: var(--text-main); padding-left: 1.2rem; line-height: 1.8; font-size: 0.9rem;">
          <li>Toca el botón <strong>"Instalar App Ahora"</strong>.</li>
          <li>O toca los tres puntos <strong>(⋮)</strong> arriba a la derecha en Chrome.</li>
          <li>Selecciona <strong>"Instalar aplicación"</strong> o <strong>"Agregar a inicio"</strong>.</li>
        </ol>
      </div>

      <div class="table-card" style="padding: 1.5rem;">
        <h3 style="color: var(--primary-gold); margin-bottom: 1rem;">🍏 Instalación en iPhone / iPad (Safari)</h3>
        <ol style="color: var(--text-main); padding-left: 1.2rem; line-height: 1.8; font-size: 0.9rem;">
          <li>Abre esta página en <strong>Safari</strong>.</li>
          <li>Toca el botón <strong>Compartir</strong> <span style="font-size: 1.1rem;">⎋</span>.</li>
          <li>Selecciona <strong>"Agregar a inicio"</strong> ➕.</li>
        </ol>
      </div>
    </div>
  `;
}

let deferredPrompt = null;
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
});

function triggerPwaInstall() {
  if (deferredPrompt) {
    deferredPrompt.prompt();
    deferredPrompt.userChoice.then(() => {
      deferredPrompt = null;
    });
  } else {
    alert('Para instalar la app en tu celular, usa la opción "Agregar a inicio" de tu navegador.');
  }
}

// Robust Immediate + Event Initialization
function bootApp() {
  initData();
  safeRenderApp();
  initFirebaseSync();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', bootApp);
} else {
  bootApp();
}
